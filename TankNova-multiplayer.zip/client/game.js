const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const menu=document.getElementById("menu"),nameInput=document.getElementById("name"),play=document.getElementById("play");
const hp=document.getElementById("hp"),level=document.getElementById("level"),score=document.getElementById("score"),playerName=document.getElementById("playerName"),rows=document.getElementById("rows");
let W=innerWidth,H=innerHeight,me=null,world={width:5000,height:3500},others=new Map(),bullets=[];
let keys={up:false,down:false,left:false,right:false},mouse={x:0,y:0,down:false},cam={x:0,y:0},ws=null,lastShot=0;

function resize(){W=canvas.width=innerWidth;H=canvas.height=innerHeight} addEventListener("resize",resize);resize();
function send(x){if(ws?.readyState===1)ws.send(JSON.stringify(x))}
function connect(){
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}`);
  ws.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.type==="welcome"){me=m.player;world=m.world}
    if(m.type==="state"){
      const seen=new Set();
      for(const p of m.players){seen.add(p.id);if(p.id===me?.id)me=p;else others.set(p.id,p)}
      for(const id of others.keys())if(!seen.has(id))others.delete(id);
    }
    if(m.type==="shot"&&m.id!==me?.id)bullets.push({x:m.x,y:m.y,a:m.angle,t:0});
  };
}
play.onclick=()=>{
  const n=(nameInput.value.trim()||"Player").slice(0,18);
  menu.style.display="none";playerName.textContent=n;connect();
  const timer=setInterval(()=>{if(ws?.readyState===1){send({type:"join",name:n});clearInterval(timer)}},100);
};

addEventListener("keydown",e=>{if(["w","ArrowUp"].includes(e.key))keys.up=true;if(["s","ArrowDown"].includes(e.key))keys.down=true;if(["a","ArrowLeft"].includes(e.key))keys.left=true;if(["d","ArrowRight"].includes(e.key))keys.right=true});
addEventListener("keyup",e=>{if(["w","ArrowUp"].includes(e.key))keys.up=false;if(["s","ArrowDown"].includes(e.key))keys.down=false;if(["a","ArrowLeft"].includes(e.key))keys.left=false;if(["d","ArrowRight"].includes(e.key))keys.right=false});
canvas.addEventListener("pointermove",e=>{mouse.x=e.clientX;mouse.y=e.clientY});
canvas.addEventListener("pointerdown",e=>{if(e.button===0)mouse.down=true});
addEventListener("pointerup",()=>mouse.down=false);

function update(){
  if(!me)return;
  send({type:"input",input:keys});
  cam.x=Math.max(0,Math.min(world.width-W,me.x-W/2));cam.y=Math.max(0,Math.min(world.height-H,me.y-H/2));
  const a=Math.atan2(mouse.y-(me.y-cam.y),mouse.x-(me.x-cam.x));
  send({type:"aim",angle:a});
  if(mouse.down&&performance.now()-lastShot>170){lastShot=performance.now();send({type:"shoot",angle:a});bullets.push({x:me.x,y:me.y,a,t:0})}
  for(const b of bullets){b.x+=Math.cos(b.a)*15;b.y+=Math.sin(b.a)*15;b.t++}
  bullets=bullets.filter(b=>b.t<65);
  hp.style.width=`${Math.max(0,me.hp/me.maxHp*100)}%`;level.textContent=me.level;score.textContent=me.score;
  leaderboard();
}
function leaderboard(){
  const list=[me,...others.values()].filter(Boolean).sort((a,b)=>b.score-a.score).slice(0,7);
  rows.innerHTML=list.map((p,i)=>`<div class="row"><span>${i+1}. ${esc(p.name)}</span><b>${p.score}</b></div>`).join("");
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

function drawTank(p,self){
  const x=p.x-cam.x,y=p.y-cam.y;
  ctx.save();ctx.translate(x,y);ctx.rotate(p.angle||0);
  ctx.fillStyle=self?"#57d9ff":"#ffbd66";ctx.fillRect(-18,-16,36,32);
  ctx.fillStyle="#252f3c";ctx.fillRect(-6,-34,12,30);
  ctx.beginPath();ctx.arc(0,0,16,0,Math.PI*2);ctx.fillStyle=self?"#9cecff":"#ffd899";ctx.fill();
  ctx.restore();
  ctx.font="12px Arial";ctx.textAlign="center";ctx.fillStyle="#fff";ctx.fillText(p.name,x,y-27);
}
function render(){
  ctx.clearRect(0,0,W,H);ctx.fillStyle="#0d151f";ctx.fillRect(0,0,W,H);
  const g=80;ctx.strokeStyle="#172433";ctx.lineWidth=1;
  for(let x=-(cam.x%g);x<W;x+=g){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
  for(let y=-(cam.y%g);y<H;y+=g){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
  ctx.strokeStyle="#57d9ff55";ctx.strokeRect(-cam.x,-cam.y,world.width,world.height);
  for(const b of bullets){ctx.beginPath();ctx.arc(b.x-cam.x,b.y-cam.y,5,0,Math.PI*2);ctx.fillStyle="#ffe36b";ctx.fill()}
  for(const p of others.values())drawTank(p,false);if(me)drawTank(me,true);
  requestAnimationFrame(render);
}
render();setInterval(update,50);

const stick=document.getElementById("joystick"),knob=document.getElementById("knob"),fire=document.getElementById("fire");let active=false;
stick.addEventListener("pointerdown",e=>{active=true;stick.setPointerCapture(e.pointerId);moveStick(e)});
stick.addEventListener("pointermove",e=>{if(active)moveStick(e)});
stick.addEventListener("pointerup",()=>{active=false;keys.up=keys.down=keys.left=keys.right=false;knob.style.left="41px";knob.style.top="41px"});
function moveStick(e){
  const r=stick.getBoundingClientRect(),dx0=e.clientX-(r.left+r.width/2),dy0=e.clientY-(r.top+r.height/2),d=Math.hypot(dx0,dy0),m=42;
  const dx=d>m?dx0/d*m:dx0,dy=d>m?dy0/d*m:dy0;knob.style.left=`${41+dx}px`;knob.style.top=`${41+dy}px`;
  keys.left=dx<-12;keys.right=dx>12;keys.up=dy<-12;keys.down=dy>12;
}
fire.addEventListener("pointerdown",()=>mouse.down=true);fire.addEventListener("pointerup",()=>mouse.down=false);
