const path = require("path");
const http = require("http");
const express = require("express");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const PORT = Number(process.env.PORT) || 8080;
const WORLD = { width: 5000, height: 3500 };
const players = new Map();

app.use(express.static(path.join(__dirname, "..", "client")));
app.get("/health", (_, res) => res.json({ ok: true, players: players.size }));

const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
const spawn = () => ({
  x: 250 + Math.random() * (WORLD.width - 500),
  y: 250 + Math.random() * (WORLD.height - 500)
});
const makeId = () => Math.random().toString(36).slice(2,10);

function publicPlayer(p) {
  return {
    id:p.id, name:p.name, x:p.x, y:p.y, angle:p.angle,
    hp:p.hp, maxHp:p.maxHp, score:p.score, level:p.level
  };
}
function broadcast(obj) {
  const data = JSON.stringify(obj);
  for (const p of players.values())
    if (p.ws.readyState === 1) p.ws.send(data);
}

wss.on("connection", ws => {
  const s = spawn();
  const p = {
    id:makeId(), ws, name:"Player", x:s.x, y:s.y, angle:0,
    hp:100, maxHp:100, score:0, level:1,
    input:{up:false,down:false,left:false,right:false}
  };
  players.set(p.id,p);

  ws.send(JSON.stringify({type:"welcome", id:p.id, world:WORLD, player:publicPlayer(p)}));

  ws.on("message", raw => {
    try {
      const m=JSON.parse(raw.toString());
      if(m.type==="join") p.name=String(m.name||"Player").slice(0,18);
      if(m.type==="input" && m.input)
        for(const k of ["up","down","left","right"]) p.input[k]=!!m.input[k];
      if(m.type==="aim" && Number.isFinite(m.angle)) p.angle=m.angle;
      if(m.type==="shoot" && Number.isFinite(m.angle)) {
        p.angle=m.angle;
        broadcast({type:"shot",id:p.id,x:p.x,y:p.y,angle:p.angle});
      }
    } catch {}
  });

  ws.on("close",()=>players.delete(p.id));
});

setInterval(() => {
  for(const p of players.values()) {
    const speed=6;
    if(p.input.up) p.y-=speed;
    if(p.input.down) p.y+=speed;
    if(p.input.left) p.x-=speed;
    if(p.input.right) p.x+=speed;
    p.x=clamp(p.x,50,WORLD.width-50);
    p.y=clamp(p.y,50,WORLD.height-50);
  }
  broadcast({type:"state",players:[...players.values()].map(publicPlayer)});
},50);

server.listen(PORT,"0.0.0.0",()=>console.log(`TankNova listening on ${PORT}`));